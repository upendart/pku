<?php

/**
 * @file
 * Stub template file.
 */

print theme('owlcarousel', array('items' => $items, 'settings' => $settings));
